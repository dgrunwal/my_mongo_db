# Optimizing Slow Queries in MongoDB: A Professional Tuning Guide

---

## Introduction

Query performance is one of the most critical factors in MongoDB deployments at scale. A single unindexed query on a large collection can stall an application, spike CPU, and cascade into broader system failures. This guide walks through the diagnostic tools, indexing strategies, schema patterns, and configuration levers that experienced engineers use to identify and fix slow queries systematically.

---

## 1. Diagnosing Slow Queries

Before tuning anything, you need to know *what* is slow and *why*.

### 1.1 Enable the Database Profiler

MongoDB's built-in profiler captures operations that exceed a threshold:

```javascript
// Log queries slower than 100ms
db.setProfilingLevel(1, { slowms: 100 });

// Log ALL queries (use cautiously in production)
db.setProfilingLevel(2);

// Check current profiling settings
db.getProfilingStatus();
```

Profiled operations are stored in `system.profile`. Query it to find offenders:

```javascript
db.system.profile.find(
  { millis: { $gt: 100 } },
  { op: 1, ns: 1, millis: 1, command: 1 }
).sort({ millis: -1 }).limit(20);
```

### 1.2 Use explain()

`explain()` is your most powerful diagnostic tool. It reveals the query plan MongoDB chose and why.

```javascript
db.orders.find({ status: "pending", customerId: 42 })
  .explain("executionStats");
```

Key fields to examine in the output:

| Field | What to Look For |
|---|---|
| `winningPlan.stage` | Should be `IXSCAN`, not `COLLSCAN` |
| `totalDocsExamined` | Should be close to `nReturned` |
| `executionTimeMillis` | The actual query time |
| `rejectedPlans` | Plans considered but not chosen |

A `COLLSCAN` (collection scan) on a large collection almost always signals a missing index.

### 1.3 MongoDB Atlas / Cloud Manager

If you're on Atlas, the **Performance Advisor** automatically identifies slow queries and recommends indexes. The **Query Profiler** tab gives a visual breakdown of operation latency over time — worth checking before diving into manual profiling.

---

## 2. Indexing Strategies

Most performance problems in MongoDB come down to missing or poorly structured indexes.

### 2.1 Single-Field Indexes

The simplest case — index one field:

```javascript
db.users.createIndex({ email: 1 });  // ascending
db.events.createIndex({ createdAt: -1 });  // descending (latest-first queries)
```

Use descending order on timestamp fields when your queries sort newest-first.

### 2.2 Compound Indexes

When queries filter or sort on multiple fields, a compound index beats multiple single-field indexes:

```javascript
// Supports: find({ status, region }) and find({ status }) but NOT find({ region }) alone
db.orders.createIndex({ status: 1, region: 1, createdAt: -1 });
```

**The ESR Rule** — structure compound indexes in this order:
1. **E**quality fields (exact match filters)
2. **S**ort fields (fields used in `.sort()`)
3. **R**ange fields (fields with `$gt`, `$lt`, `$in`, etc.)

```javascript
// Query: find({ status: "active" }).sort({ createdAt: -1 }).hint(...)
// Bad:  { createdAt: -1, status: 1 }
// Good: { status: 1, createdAt: -1 }  ← equality before sort
db.sessions.createIndex({ status: 1, createdAt: -1 });
```

### 2.3 Covered Queries

A query is *covered* when the index contains all the fields the query needs — MongoDB never touches the actual documents. This is the fastest possible read:

```javascript
db.products.createIndex({ category: 1, price: 1, _id: 0 });

// This query is fully covered — zero document reads
db.products.find(
  { category: "electronics" },
  { price: 1, _id: 0 }
);
```

Verify coverage in `explain()` output: `totalDocsExamined` should be `0`.

### 2.4 Partial Indexes

Index only the subset of documents you actually query. Smaller index = faster lookups and less memory:

```javascript
// Only index open orders — no point indexing completed/cancelled ones
db.orders.createIndex(
  { customerId: 1, createdAt: -1 },
  { partialFilterExpression: { status: "open" } }
);
```

### 2.5 Text Indexes

For full-text search within MongoDB (though dedicated search engines like Atlas Search or Elasticsearch are preferable at scale):

```javascript
db.articles.createIndex({ title: "text", body: "text" });

db.articles.find({ $text: { $search: "mongodb performance" } });
```

### 2.6 Wildcard Indexes

When document structure is unpredictable and you need to query arbitrary fields:

```javascript
db.events.createIndex({ "metadata.$**": 1 });
```

Use sparingly — wildcard indexes are large and have overhead. Prefer explicit compound indexes when field names are known.

---

## 3. Query Patterns to Avoid

### 3.1 Unanchored Regex

Leading-wildcard regex cannot use an index and forces a collection scan:

```javascript
// Bad — cannot use index
db.users.find({ name: /.*smith/i });

// Better — anchored regex CAN use an index
db.users.find({ name: /^Smith/i });

// Best for full-text — use a text index
db.users.find({ $text: { $search: "smith" } });
```

### 3.2 Negation Operators

`$ne`, `$nin`, and `$not` are difficult to index efficiently and often scan large portions of the collection:

```javascript
// Problematic — scans everything that is NOT "cancelled"
db.orders.find({ status: { $ne: "cancelled" } });

// Better — reframe as a positive query using $in
db.orders.find({ status: { $in: ["pending", "processing", "shipped"] } });
```

### 3.3 Large `$in` Arrays

`$in` with hundreds of values can degrade performance. Consider chunking queries or restructuring the data model:

```javascript
// Risky at scale
db.products.find({ _id: { $in: arrayOfThousandIds } });

// Better: batch into smaller chunks of 100–200
```

### 3.4 `$where` and JavaScript Execution

Avoid `$where` — it executes JavaScript server-side, bypasses indexes, and cannot be parallelized:

```javascript
// Never do this
db.orders.find({ $where: "this.total > this.budget" });

// Do this instead
db.orders.find({ $expr: { $gt: ["$total", "$budget"] } });
```

---

## 4. Aggregation Pipeline Optimization

Aggregation pipelines need careful ordering to avoid processing unnecessary data.

### 4.1 Filter Early with $match and $limit

Always place `$match` as early as possible in the pipeline. MongoDB can push early `$match` stages into index scans:

```javascript
// Bad — $group runs on the entire collection first
db.sales.aggregate([
  { $group: { _id: "$region", total: { $sum: "$amount" } } },
  { $match: { total: { $gt: 10000 } } }
]);

// Good — $match filters documents before $group
db.sales.aggregate([
  { $match: { date: { $gte: ISODate("2024-01-01") } } },
  { $group: { _id: "$region", total: { $sum: "$amount" } } },
  { $match: { total: { $gt: 10000 } } }
]);
```

### 4.2 Project Early to Reduce Document Size

Strip fields you don't need before expensive stages like `$group` or `$lookup`:

```javascript
db.orders.aggregate([
  { $match: { status: "complete" } },
  { $project: { customerId: 1, amount: 1, _id: 0 } },  // drop large fields early
  { $group: { _id: "$customerId", total: { $sum: "$amount" } } }
]);
```

### 4.3 $lookup Performance

`$lookup` (join) is expensive. Mitigate it by:
- Filtering with `$match` before the lookup
- Adding an index on the foreign collection's join field
- Using `pipeline` form of `$lookup` to apply conditions on the joined collection

```javascript
// Index the foreign key
db.products.createIndex({ productId: 1 });

db.orders.aggregate([
  { $match: { status: "pending" } },  // filter first
  {
    $lookup: {
      from: "products",
      localField: "productId",
      foreignField: "productId",
      as: "product"
    }
  }
]);
```

### 4.4 Use allowDiskUse for Large Aggregations

By default, aggregation stages are limited to 100MB of RAM. For large datasets:

```javascript
db.events.aggregate(
  [ /* pipeline */ ],
  { allowDiskUse: true }
);
```

Note: disk use is slower than in-memory — it's a fallback, not a strategy. If you're hitting this regularly, revisit your pipeline or add indexes.

---

## 5. Schema Design for Performance

MongoDB gives you flexibility in schema design, but that flexibility has performance implications.

### 5.1 Embedding vs. Referencing

**Embed** when data is accessed together and the embedded array won't grow unboundedly:

```javascript
// Good embedding — address is always read with user
{
  _id: ObjectId(),
  name: "Alice",
  address: { street: "123 Main St", city: "Austin", zip: "78701" }
}
```

**Reference** when related data is large, frequently updated independently, or shared across documents:

```javascript
// Order references product by ID — product data isn't duplicated
{ _id: ObjectId(), productId: ObjectId("..."), quantity: 3, price: 29.99 }
```

### 5.2 Avoid Unbounded Arrays

Arrays that grow without limit bloat documents and degrade index performance:

```javascript
// Dangerous pattern — messages array grows forever
{ userId: 1, messages: [ ...thousands of messages... ] }

// Better — separate collection with reference
{ _id: ObjectId(), userId: 1, body: "Hello", createdAt: ISODate() }
```

### 5.3 The Bucket Pattern

For time-series or high-volume event data, bucket multiple events into one document to reduce document count and improve compression:

```javascript
// Instead of one document per sensor reading:
{
  sensorId: "sensor-42",
  hour: ISODate("2024-06-01T14:00:00Z"),
  readings: [
    { ts: ISODate("2024-06-01T14:00:05Z"), temp: 72.1 },
    { ts: ISODate("2024-06-01T14:00:10Z"), temp: 72.3 },
    // ... up to ~200 readings per bucket
  ],
  count: 200,
  minTemp: 71.8,
  maxTemp: 73.0
}
```

---

## 6. Connection and Configuration Tuning

### 6.1 Connection Pool Sizing

Each MongoDB driver maintains a connection pool. Default settings are conservative — tune for your workload:

```javascript
// Node.js (Mongoose / mongodb driver)
const client = new MongoClient(uri, {
  maxPoolSize: 50,      // max concurrent connections (default: 100)
  minPoolSize: 10,      // keep warm connections alive
  maxIdleTimeMS: 30000  // close idle connections after 30s
});
```

Too few connections causes queuing under load. Too many can overwhelm `mongod`. Start with `maxPoolSize` at 50–100 and tune based on observed wait times.

### 6.2 Read Preferences

For read-heavy workloads with replica sets, distribute reads to secondaries:

```javascript
db.orders.find({ status: "complete" })
  .readPref("secondaryPreferred");
```

Use `primaryPreferred` when you need the freshest data but can tolerate slight staleness under primary load. Never use `secondary` for data that must be current.

### 6.3 Write Concern

Balance durability vs. performance:

```javascript
// Fast writes — acknowledged by primary only (default)
db.logs.insertOne(doc, { writeConcern: { w: 1 } });

// Durable writes — acknowledged by majority of replica set
db.payments.insertOne(doc, { writeConcern: { w: "majority", j: true } });
```

For non-critical bulk operations (logs, analytics events), `w: 0` (fire-and-forget) can dramatically increase throughput at the cost of durability.

---

## 7. Monitoring and Ongoing Maintenance

Tuning is not a one-time event. Performance changes as data grows and query patterns evolve.

### 7.1 Key Metrics to Monitor

- **`serverStatus().opcounters`** — query, insert, update, delete rates
- **`serverStatus().wiredTiger.cache`** — cache eviction pressure (high eviction = not enough RAM)
- **Index hit rate** — via `$indexStats` aggregation
- **Replication lag** — secondaries falling behind primary signals write pressure

```javascript
// Check index usage statistics
db.orders.aggregate([{ $indexStats: {} }]);
```

### 7.2 Remove Unused Indexes

Unused indexes waste RAM and slow down writes. Identify them:

```javascript
// Indexes with zero accesses since last restart
db.orders.aggregate([
  { $indexStats: {} },
  { $match: { "accesses.ops": 0 } }
]);
```

Drop indexes you're confident are unused — but do so carefully in production.

### 7.3 Rolling Index Builds

Building indexes on large collections blocks writes. On replica sets, use rolling builds:

1. Remove a secondary from the set
2. Build the index on it standalone
3. Re-add it to the set
4. Repeat for remaining secondaries, then primary

Or use MongoDB 4.2+ `createIndex` with `background: true` (deprecated in 4.4+) or the newer online index builds that don't hold a global lock.

---

## Quick Reference Checklist

Before deploying any query-heavy feature, run through this checklist:

- [ ] `explain("executionStats")` shows `IXSCAN`, not `COLLSCAN`
- [ ] `totalDocsExamined` is close to `nReturned`
- [ ] Compound index follows the **ESR rule**
- [ ] Aggregation pipeline has `$match` as the first stage
- [ ] No leading-wildcard regex on large collections
- [ ] No `$where` clauses
- [ ] Unbounded arrays have a growth cap or are in a separate collection
- [ ] Connection pool is sized to the expected concurrency level
- [ ] Write concern matches the durability requirements of each operation
- [ ] Index usage is monitored and unused indexes are removed periodically

---

*MongoDB version references: MongoDB 6.x / 7.x. Some features (online index builds, `$expr`, `$lookup` pipeline syntax) require MongoDB 4.4+.*
